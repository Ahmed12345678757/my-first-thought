// تعيين التاريخ الحالي
document.getElementById("inspectionDate").valueAsDate = new Date();

// تبديل حالة الدائرة
function toggleCircle(element, color) {
    const row = element.closest("tr");
    const blueCircle = row.querySelector(".circle.blue");
    const redCircle = row.querySelector(".circle.red");

    if (color === "blue") {
        if (blueCircle.classList.contains("active")) {
            blueCircle.classList.remove("active");
            blueCircle.style.backgroundColor = "";
        } else {
            blueCircle.classList.add("active");
            blueCircle.style.backgroundColor = "#3498db";
            redCircle.classList.remove("active");
            redCircle.style.backgroundColor = "";
        }
    } else if (color === "red") {
        if (redCircle.classList.contains("active")) {
            redCircle.classList.remove("active");
            redCircle.style.backgroundColor = "";
        } else {
            redCircle.classList.add("active");
            redCircle.style.backgroundColor = "#e74c3c";
            blueCircle.classList.remove("active");
            blueCircle.style.backgroundColor = "";
        }
    }
}

// حفظ البيانات في localStorage
function saveData() {
    const data = {
        department: document.getElementById("department").value,
        meterNumber: document.getElementById("meterNumber").value,
        vehicleType: document.getElementById("vehicleType").value,
        vehiclePlate: document.getElementById("vehiclePlate").value,
        notes: document.getElementById("notes").value,
        inspectionDate: document.getElementById("inspectionDate").value,
        delivererName: document.getElementById("delivererName").value,
        delivererSignature: document.getElementById("delivererSignatureCanvas").toDataURL(),
        receiverName: document.getElementById("receiverName").value,
        receiverSignature: document.getElementById("receiverSignatureCanvas").toDataURL(),
        // Save circle states
        ...Array.from(document.querySelectorAll(".inspection-table tbody tr")).reduce((acc, row) => {
            const itemName = row.cells[0].innerText;
            const blueCircle = row.cells[1].querySelector(".circle.blue");
            const redCircle = row.cells[2].querySelector(".circle.red");
            let status = "";
            if (blueCircle.classList.contains("active")) {
                status = "سليم";
            } else if (redCircle.classList.contains("active")) {
                status = "غير سليم";
            }
            acc[`status_${itemName}`] = status;
            return acc;
        }, {})
    };

    localStorage.setItem("inspectionData", JSON.stringify(data));
    alert("تم حفظ البيانات بنجاح!");
}

// تحميل البيانات من localStorage
window.addEventListener("load", function() {
    const savedData = localStorage.getItem("inspectionData");
    if (savedData) {
        const data = JSON.parse(savedData);
        document.getElementById("department").value = data.department || "";
        document.getElementById("meterNumber").value = data.meterNumber || "";
        document.getElementById("vehicleType").value = data.vehicleType || "";
        document.getElementById("vehiclePlate").value = data.vehiclePlate || "";
        document.getElementById("notes").value = data.notes || "";
        document.getElementById("inspectionDate").value = data.inspectionDate || "";
        document.getElementById("delivererName").value = data.delivererName || "";
        if (data.delivererSignature) {
            const canvas = document.getElementById("delivererSignatureCanvas");
            if (canvas) {
                const ctx = canvas.getContext("2d");
                const img = new Image();
                img.onload = function() {
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    ctx.drawImage(img, 0, 0);
                };
                img.src = data.delivererSignature;
            }
        }
        document.getElementById("receiverName").value = data.receiverName || "";
        if (data.receiverSignature) {
            const canvas = document.getElementById("receiverSignatureCanvas");
            if (canvas) {
                const ctx = canvas.getContext("2d");
                const img = new Image();
                img.onload = function() {
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    ctx.drawImage(img, 0, 0);
                };
                img.src = data.receiverSignature;
            }
        }

        // Load circle states
        const tableRows = document.querySelectorAll(".inspection-table tbody tr");
        tableRows.forEach(row => {
            const itemName = row.cells[2].innerText;
            const savedStatus = data[`status_${itemName}`];
            const blueCircle = row.cells[1].querySelector(".circle.blue");
            const redCircle = row.cells[0].querySelector(".circle.red");

            if (savedStatus === "سليم") {
                blueCircle.classList.add("active");
                blueCircle.style.backgroundColor = "#3498db";
                redCircle.classList.remove("active");
                redCircle.style.backgroundColor = "";
            } else if (savedStatus === "غير سليم") {
                redCircle.classList.add("active");
                redCircle.style.backgroundColor = "#e74c3c";
                blueCircle.classList.remove("active");
                blueCircle.style.backgroundColor = "";
            }
        });
    }
});

// نسخ المحتوى
function copyToClipboard() {
    try {
        const text = generateInspectionText();
        navigator.clipboard.writeText(text).then(() => {
            alert("تم نسخ المحتوى بنجاح!");
        }).catch(() => {
            alert("فشل النسخ. حاول مرة أخرى.");
        });
    } catch (error) {
        alert("حدث خطأ أثناء النسخ");
    }
}

// مشاركة عبر WhatsApp
function shareViaWhatsApp() {
    try {
        const message = generateInspectionText();
        const whatsappUrl = "https://wa.me/?text=" + encodeURIComponent(message);
        window.open(whatsappUrl, "_blank");
    } catch (error) {
        alert("حدث خطأ أثناء المشاركة");
    }
}

function generateInspectionText() {
    let text = "محضر فحص السيارة\n";
    text += "هيئة الهلال الأحمر السعودي\n\n";

    text += "الإدارة العامة بالمنطقة الشرقية: " + document.getElementById("department").value + "\n";
    text += "رقم العداد: " + document.getElementById("meterNumber").value + "\n";
    text += "النوع: " + document.getElementById("vehicleType").value + "\n";
    text += "رقم اللوحة: " + document.getElementById("vehiclePlate").value + "\n\n";

    text += "--- جدول الفحص ---\n";
    const tableRows = document.querySelectorAll(".inspection-table tbody tr");
    tableRows.forEach(row => {
        const itemName = row.cells[0].innerText;
        const blueCircle = row.cells[1].querySelector(".circle.blue");
        const redCircle = row.cells[2].querySelector(".circle.red");
        let status = "لم يتم تحديده";
        if (blueCircle && blueCircle.classList.contains("active")) {
            status = "سليم";
        } else if (redCircle && redCircle.classList.contains("active")) {
            status = "غير سليم";
        }

        text += itemName + ": " + status + "\n";
    });

    text += "\n--- الملاحظات ---\n";
    text += document.getElementById("notes").value + "\n\n";

    text += "التاريخ: " + document.getElementById("inspectionDate").value + "\n\n";

    text += "--- التوقيعات ---\n";
    text += "المسلم: " + document.getElementById("delivererName").value + "\n";
    text += "المستلم: " + document.getElementById("receiverName").value + "\n";
    // For text output, we can't include the drawing directly, but we can indicate its presence.
    text += "توقيع المسلم: (مرفق في PDF)" + "\n";
    text += "توقيع المستلم: (مرفق في PDF)" + "\n";

    return text;
}

function generatePdf() {
    const element = document.querySelector(".container");
    html2pdf().from(element).save();
}

// Signature Pad functionality
let isDrawing = false;
let lastX = 0;
let lastY = 0;

function setupSignaturePad(canvasId) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    ctx.lineWidth = 2;
    ctx.lineCap = "round";
    ctx.strokeStyle = "#000";

    function draw(e) {
        if (!isDrawing) return;
        ctx.beginPath();
        ctx.moveTo(lastX, lastY);
        ctx.lineTo(e.offsetX, e.offsetY);
        ctx.stroke();
        [lastX, lastY] = [e.offsetX, e.offsetY];
    }

    canvas.addEventListener("mousedown", (e) => {
        isDrawing = true;
        [lastX, lastY] = [e.offsetX, e.offsetY];
    });

    canvas.addEventListener("mousemove", draw);
    canvas.addEventListener("mouseup", () => isDrawing = false);
    canvas.addEventListener("mouseout", () => isDrawing = false);

    // Touch events for mobile
    canvas.addEventListener("touchstart", (e) => {
        e.preventDefault(); // Prevent scrolling
        isDrawing = true;
        const touch = e.touches[0];
        const rect = canvas.getBoundingClientRect();
        [lastX, lastY] = [touch.clientX - rect.left, touch.clientY - rect.top];
    });

    canvas.addEventListener("touchmove", (e) => {
        e.preventDefault(); // Prevent scrolling
        if (!isDrawing) return;
        const touch = e.touches[0];
        const rect = canvas.getBoundingClientRect();
        ctx.beginPath();
        ctx.moveTo(lastX, lastY);
        ctx.lineTo(touch.clientX - rect.left, touch.clientY - rect.top);
        ctx.stroke();
        [lastX, lastY] = [touch.clientX - rect.left, touch.clientY - rect.top];
    });

    canvas.addEventListener("touchend", () => isDrawing = false);
    canvas.addEventListener("touchcancel", () => isDrawing = false);

    // Clear button functionality
    const clearButton = document.querySelector(`.clear-signature-btn[data-canvas-id="${canvasId}"]`);
    if (clearButton) {
        clearButton.addEventListener("click", () => {
            ctx.clearRect(0, 0, canvas.width, canvas.height);
        });
    }
}

document.addEventListener("DOMContentLoaded", () => {
    setupSignaturePad("delivererSignatureCanvas");
    setupSignaturePad("receiverSignatureCanvas");
});

